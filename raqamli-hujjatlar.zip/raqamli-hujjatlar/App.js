import React, { useState } from 'react';
import { SafeAreaView, View, Text, TextInput, ScrollView, Image, StyleSheet, TouchableOpacity } from 'react-native';

const initialDocuments = [
  { 
    id: '1', 
    title: '2026-yilgi Mehnat shartnomasi', 
    preview: 'https://cdn.vectorstock.com/i/1000v/14/32/document-signature-icon-flat-style-vector-61661432.jpg', 
    type: 'Shartnoma' 
  },
  { 
    id: '2', 
    title: 'Moliyaviy hisobot – Q1 2026', 
    preview: 'https://as1.ftcdn.net/jpg/02/05/73/40/1000_F_205734094_kplWyrdxKVEv6DOrVfvIrOix1RS9vY4W.jpg', 
    type: 'Hisobot' 
  },
  { 
    id: '3', 
    title: 'Direktor buyrug‘i №45', 
    preview: 'https://thumbs.dreamstime.com/b/paper-official-certificate-29271453.jpg', 
    type: 'Buyruq' 
  },
  { 
    id: '4', 
    title: 'Arxiv – 2025-yilgi shartnomalar', 
    preview: 'https://as1.ftcdn.net/jpg/04/95/61/72/1000_F_495617214_pIv4oFA2CSJAny54FIdCZ3G2636aFXMY.jpg', 
    type: 'Arxiv' 
  },
  { 
    id: '5', 
    title: 'Xodimlar ro‘yxati (yangilangan)', 
    preview: 'https://as1.ftcdn.net/jpg/04/95/61/72/1000_F_495617214_pIv4oFA2CSJAny54FIdCZ3G2636aFXMY.jpg', 
    type: 'Arxiv' 
  },
  { 
    id: '6', 
    title: 'Tender hujjatlari – 2026', 
    preview: 'https://thumbs.dreamstime.com/b/contract-document-icon-legal-agreement-form-vector-design-generative-ai-clear-explicitly-displaying-file-labeled-representing-411239123.jpg', 
    type: 'Tender' 
  },
];

export default function App() {
  const [search, setSearch] = useState('');
  
  const filtered = initialDocuments.filter(doc =>
    doc.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.headerText}>📄 Elektron Hujjatlar</Text>
      </View>

      {/* SEARCHBAR */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Hujjat nomi bo‘yicha qidirish..."
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* SCROLL VIEW WITH CARDS */}
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {filtered.map(doc => (
          <TouchableOpacity 
            key={doc.id} 
            style={styles.card} 
            onPress={() => alert(`Hujjat ochilmoqda: ${doc.title}\nTuri: ${doc.type}`)}
          >
            <Image 
              source={{ uri: doc.preview }} 
              style={styles.previewImage} 
              resizeMode="contain"  // Ikonka uchun "contain" yaxshiroq ko'rinadi
            />
            <View style={styles.cardContent}>
              <Text style={styles.title} numberOfLines={2}>{doc.title}</Text>
              <Text style={[styles.type, { color: getTypeColor(doc.type) }]}>
                {doc.type}
              </Text>
            </View>
          </TouchableOpacity>
        ))}

        {filtered.length === 0 && (
          <Text style={styles.noResults}>Hech qanday hujjat topilmadi</Text>
        )}
      </ScrollView>

      {/* FOOTER */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>© 2026 Elektron Hujjatlar Tizimi</Text>
      </View>
    </SafeAreaView>
  );
}

// Hujjat turiga qarab rang berish (ixtiyoriy, chiroyliroq ko'rinishi uchun)
const getTypeColor = (type) => {
  switch (type) {
    case 'Shartnoma': return '#0d6efd';    // ko'k
    case 'Hisobot':   return '#28a745';    // yashil
    case 'Buyruq':    return '#dc3545';    // qizil
    case 'Arxiv':     return '#6c757d';    // kulrang
    case 'Tender':    return '#fd7e14';    // to'q sariq
    default:          return '#6c757d';
  }
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#f8f9fa' 
  },
  header: { 
    height: 80, 
    backgroundColor: '#0d6efd', 
    justifyContent: 'center', 
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  headerText: { 
    color: '#fff', 
    fontSize: 26, 
    fontWeight: 'bold' 
  },
  searchContainer: { 
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee'
  },
  searchInput: { 
    backgroundColor: '#f1f3f5', 
    borderRadius: 30, 
    paddingHorizontal: 20,
    paddingVertical: 14, 
    fontSize: 16, 
    borderWidth: 1, 
    borderColor: '#dee2e6'
  },
  scrollContent: { 
    paddingHorizontal: 16, 
    paddingBottom: 30,
    paddingTop: 8
  },
  card: { 
    flexDirection: 'row', 
    backgroundColor: '#ffffff', 
    borderRadius: 16, 
    marginBottom: 16, 
    overflow: 'hidden', 
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1, 
    shadowRadius: 6, 
    elevation: 4,
    borderWidth: 1,
    borderColor: '#f0f0f0'
  },
  previewImage: { 
    width: 110, 
    height: 110,
    backgroundColor: '#f8f9fa',  // agar rasm yuklanmasa fon ko'rinadi
  },
  cardContent: { 
    flex: 1, 
    padding: 14, 
    justifyContent: 'center' 
  },
  title: { 
    fontSize: 17, 
    fontWeight: '600', 
    marginBottom: 6,
    color: '#212529'
  },
  type: { 
    fontSize: 14, 
    fontWeight: '500'
  },
  footer: { 
    height: 56, 
    backgroundColor: '#f1f3f5', 
    justifyContent: 'center', 
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#dee2e6'
  },
  footerText: { 
    fontSize: 14, 
    color: '#6c757d' 
  },
  noResults: {
    textAlign: 'center',
    fontSize: 16,
    color: '#6c757d',
    marginTop: 40,
    fontStyle: 'italic'
  }
});